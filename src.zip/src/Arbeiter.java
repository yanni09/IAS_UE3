
public class Arbeiter extends Person {

	public Arbeiter(int einkommen) {
		super(einkommen);
	}
	public Arbeiter(int einkommen, String name) { // Optional
		super(einkommen, name);
	}

	@Override public int zuVersteuerndesEinkommen() {
		int einkommen = super.zuVersteuerndesEinkommen() - 2400;
		//return Math.max(einkommen, 0);
		if (einkommen >= 0) 
			return einkommen;
		else
			return 0;
	}
}
