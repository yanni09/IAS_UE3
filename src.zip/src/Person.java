public class Person {
	private int einkommen;
	private String name = "";		// Optional
	
	public Person(int einkommen) { 
		this.einkommen = einkommen; 
	}
	public Person(int einkommen, String name) { // Optional
		this.einkommen = einkommen;
		this.name = name;
	}
	
	public int zuVersteuerndesEinkommen() {
		return einkommen;
	}
	
	private final double STEUER_SATZ = 0.25;
	
	public int steuer() {
		double steuer = Math.floor( STEUER_SATZ * this.zuVersteuerndesEinkommen() );
		return (int) steuer;
	}
	
	@Override public String toString() {
		int netto = this.einkommen - this.steuer();
		String className = this.getClass().getName();
		return className + "(" +
				this.name +		// Optional
				"): " +
				"\n\t\t Brutto-Einkommen: " + this.einkommen +
				"\n\t\t zu verst. Einkommen: " + this.zuVersteuerndesEinkommen() +
				"\n\t\t Steuer: " + this.steuer() +
				"\n\t\t Netto-Einkommen: " + netto; 
	}
}
