
public class K�nigin extends Person {

	public K�nigin(int einkommen) {
		super(einkommen);
	}
	public K�nigin(int einkommen, String name) { // Optional
		super(einkommen, name);
	}

	
	@Override public int steuer() {
		return 0;		// das ist sicher
	}

	@Override public int zuVersteuerndesEinkommen() {
		return 0;		// optional 
	}
}
