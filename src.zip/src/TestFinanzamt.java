
public class TestFinanzamt {

	public static void main(String[] args) {
		Finanzamt finanzamt = new Finanzamt();
		
		Person[] personen = {
				new Person(     6400 , "Joe Unemployed"),	// Name: Optional
				new Arbeiter(  36000 , "Suzi Hard-working"),
				new Banker(  4000000 , "Fred Moneymaker"),
				new K�nigin( 1000000 , "Elisabeth")
//				new Person(     6400 ),
//				new Arbeiter(  36000 ),
//				new Banker(  4000000 ),
//				new K�nigin( 1000000 )
		};
		
		for (int i = 0; i < personen.length; i++) {
			System.out.println("Person[" + i + "]: "
						+ personen[i]);
//						+ " zu verst. Einkommen = " + personen[i].zuVersteuerndesEinkommen()
//						+ ", Steuer = " + personen[i].steuer());
		}
		System.out.println();
		
		int steuerGesamt = finanzamt.berechneSteuer( personen );
		System.out.println("Gesamte Steuern = " + steuerGesamt);
		
		
		// TODO: Testf�lle
		//	- Banker: Steuer (+1000) nicht gr��er als Einkommen
		//	- Arbeiter: zuVersteuerndesEinkommen nicht negativ
		// 	- Arbeiter: Steuer 25% von (Einkommen -2400) (korrekt), 
		//			    oder 25% von Einkommen (falsch --> Freibetrag fehlt) 
		//			    oder 25% Einkommen - 2400 (falsch --> Freibetrage: 9.600 !!!)
	}
}
