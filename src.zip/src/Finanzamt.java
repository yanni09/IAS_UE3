
public class Finanzamt {

	public int berechneSteuer(Person[] einwohner) {
		int tax = 0;
		for (int i = 0; i < einwohner.length; i++) {
			tax += einwohner[i].steuer();
		}
		
		return tax;
	}
}
