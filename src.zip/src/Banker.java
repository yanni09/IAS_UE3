
public class Banker extends Person {

	public Banker(int einkommen) {
		super(einkommen);
	}
	public Banker(int einkommen, String name) { // Optional
		super(einkommen, name);
	}
	
	@Override public int steuer() {
		// aufpassen: Steuer > Einkommen m�glich --> max. Einkommen zur�ckgeben
		//return super.steuer() + 1000;
		return Math.min(super.steuer() + 1000 /* Steuer*/,
						this.zuVersteuerndesEinkommen() /* Einkommen */ );
	}

}
